Gulf Of Saros example inputs

- Extract this folder inside examples.
- Run telemac_preprocess from the repository root.
- Outer boundary: outline.txt
- Bathymetry XYZ: bathymetry.txt
- Optional island boundaries: islands.txt
- Choose mesh sizes and refinement regions for your application.
- Input coordinates and elevations are preserved from the supplied dataset.
